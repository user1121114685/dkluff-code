The MPQ Browser will automatically extract a list of files from the MPQ.
Some MPQ's however lacks a listfile (or the listfile doesn't contain
all files) so you will be unable to see its contents without a custom
listfile.

To use a custom listfile, place it in this folder with exactly the same
name as the MPQ, but with the extention ".txt" instead. Don't create
any subfolders even if the MPQ resides in a subfolder.

To stop using the custom listfile simply rename or remove it.
