The MPQ Browser will display icons for the various file types.
If you want to use your own icons, or add/remove certain icons
then add/remove them from this folder.

An icon is named "EXTENTION.ico", where "EXTENTION" is the
extention of the file. As an example, the file "exe.ico" will
make all exe files in the MPQ Browser use that icon.

Icons needs to be 16x16 in 8-bit colors.
